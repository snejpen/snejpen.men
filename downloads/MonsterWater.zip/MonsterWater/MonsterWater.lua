-- Monster Water: swaps the icon of every rank of Conjured Water for a Monster Energy Ultra can.
--
-- Item icons come from the game's data files, which addons can't edit. Instead
-- we hook SetTexture on every texture in the UI: whenever anything (bags, action
-- bars, loot window, trade, vendor, tooltips, most bag addons) tries to show the
-- Conjured Water icon, we show our image instead.

local ADDON_NAME = ...

-- Every rank of mage water. The Conjured Water icon is different on each rank, so
-- we look up each item's icon from the game itself instead of hard-coding file IDs.
-- Ranks that don't exist in your version of the game are simply skipped.
local WATER_ITEMS = {
    5350,  -- Conjured Water
    2288,  -- Conjured Fresh Water
    2136,  -- Conjured Purified Water
    3772,  -- Conjured Spring Water
    8077,  -- Conjured Mineral Water
    8078,  -- Conjured Sparkling Water
    8079,  -- Conjured Crystal Water
    30703, -- Conjured Mountain Spring Water
    22018, -- Conjured Glacier Water
}

local NEW_ICON = "Interface\\AddOns\\" .. ADDON_NAME .. "\\MonsterUltra"

local getItemInfoInstant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant

local waterIcons = {} -- [icon file ID] = true

local function AddWaterIcons()
    if not getItemInfoInstant then
        waterIcons[132793] = true -- fall back to the original Conjured Water icon
        return
    end
    for _, itemID in ipairs(WATER_ITEMS) do
        local _, _, _, _, icon = getItemInfoInstant(itemID)
        if icon then
            waterIcons[icon] = true
        end
    end
    if not next(waterIcons) then
        waterIcons[132793] = true
    end
end
AddWaterIcons()

-- Some UI code passes a path string instead of a file ID; catch that too.
local function IsWaterIcon(tex)
    if type(tex) == "number" then
        return waterIcons[tex] == true
    end
    if type(tex) == "string" then
        local id = tonumber(tex)
        if id then
            return waterIcons[id] == true
        end
        if GetFileIDFromPath then
            id = GetFileIDFromPath(tex)
            return id ~= nil and waterIcons[id] == true
        end
    end
    return false
end

-- All Texture objects share one metatable, so hooking it covers every texture,
-- including ones created later. hooksecurefunc runs after the original call
-- and doesn't taint Blizzard's secure code.
local textureMeta = getmetatable(UIParent:CreateTexture()).__index

hooksecurefunc(textureMeta, "SetTexture", function(self, tex)
    if tex ~= nil and IsWaterIcon(tex) then
        self:SetTexture(NEW_ICON) -- re-enters the hook with NEW_ICON, which is ignored
    end
end)

-- Some frames pass the icon through SetItemButtonTexture; it ends in SetTexture
-- so the hook above already handles it. Same for action buttons.

-- /mw to check it's loaded
SLASH_MONSTERWATER1 = "/mw"
SlashCmdList.MONSTERWATER = function()
    print("|cff9fd5ffMonster Water|r: All Conjured Water ranks are now Monster Ultra. |T" .. NEW_ICON .. ":16|t")
end
