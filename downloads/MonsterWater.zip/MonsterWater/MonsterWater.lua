-- Monster Water: swaps the Conjured Water icon for a Monster Energy Ultra can.
--
-- Item icons come from the game's data files, which addons can't edit. Instead
-- we hook SetTexture on every texture in the UI: whenever anything (bags, action
-- bars, loot window, trade, vendor, tooltips, most bag addons) tries to show the
-- Conjured Water icon, we show our image instead.

local ADDON_NAME = ...

local OLD_ICON = 132793 -- Conjured Water's icon file ID
local NEW_ICON = "Interface\\AddOns\\" .. ADDON_NAME .. "\\MonsterUltra"

-- Some UI code passes a path string instead of a file ID; catch that too.
local function IsWaterIcon(tex)
    if tex == OLD_ICON then
        return true
    end
    if type(tex) == "string" then
        if tonumber(tex) == OLD_ICON then
            return true
        end
        if GetFileIDFromPath and GetFileIDFromPath(tex) == OLD_ICON then
            return true
        end
    end
    return false
end

-- All Texture objects share one metatable, so hooking it covers every texture,
-- including ones created later. hooksecurefunc runs after the original call
-- and doesn't taint Blizzard's secure code.
local textureMeta = getmetatable(UIParent:CreateTexture()).__index

hooksecurefunc(textureMeta, "SetTexture", function(self, tex)
    if tex ~= nil and IsWaterIcon(tex) then
        self:SetTexture(NEW_ICON) -- re-enters the hook with NEW_ICON, which is ignored
    end
end)

-- Some frames pass the icon through SetItemButtonTexture; it ends in SetTexture
-- so the hook above already handles it. Same for action buttons.

-- /mw to check it's loaded
SLASH_MONSTERWATER1 = "/mw"
SlashCmdList.MONSTERWATER = function()
    print("|cff9fd5ffMonster Water|r: Conjured Water is now Monster Ultra. |T" .. NEW_ICON .. ":16|t")
end
